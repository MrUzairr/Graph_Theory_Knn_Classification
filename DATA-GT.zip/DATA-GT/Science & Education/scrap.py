import requests
from bs4 import BeautifulSoup

# Function to scrape paragraph from a webpage
def scrape_paragraph(url):
    # Send a GET request to the URL
    response = requests.get(url)
    print(response)
    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        # Parse the HTML content of the page
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Find the paragraph element you want to scrape
        paragraph = soup.find('p')
        
        # Check if paragraph element is found
        if paragraph:
            # Extract the text from the paragraph
            paragraph_text = paragraph.get_text()
            return paragraph_text
        else:
            print("Paragraph element not found.")
    else:
        print("Failed to retrieve webpage. Status code:", response.status_code)

# URL of the webpage you want to scrape
url = 'https://www.ukessays.com/essays/education/the-benefits-of-science-education-essay.php'

# Call the function to scrape paragraph
paragraph = scrape_paragraph(url)

# Print the scraped paragraph
if paragraph:
    print("Scraped paragraph:")
    print(paragraph)
