import os
import requests
from bs4 import BeautifulSoup
from docx import Document

def scrape_website(url):
    try:
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            return response.text
        else:
            print("Failed to fetch page:", response.status_code)
            return None
    except Exception as e:
        print("An error occurred:", e)
        return None

def extract_text_from_html(html_content):
    try:
        soup = BeautifulSoup(html_content, 'html.parser')
        # Find all paragraphs and extract their text
        paragraphs = soup.find_all('p')
        text = '\n'.join(paragraph.get_text() for paragraph in paragraphs)
        return text
    except Exception as e:
        print("An error occurred while extracting text:", e)
        return None

def save_text_to_word(text, filename):
    try:
        document = Document()
        document.add_paragraph(text)
        directory = r'C:\Users\faiza\Documents\Semester 6\GT\Semester Project\Health and Fitness'
        filepath = os.path.join(directory, filename)
        document.save(filepath)
        print("Data saved successfully to:", filepath)
    except Exception as e:
        print("An error occurred while saving data to Word file:", e)

# Example usage:
url = 'https://www.totalhealthandfitness.com/what-does-it-mean-to-have-total-health-and-fitness/'
html_content = scrape_website(url)
if html_content:
    text = extract_text_from_html(html_content)
    if text:
        filename = '15.docx'
        save_text_to_word(text, filename)
    else:
        print("Failed to extract text from HTML.")
else:
    print("Failed to fetch webpage content.")
